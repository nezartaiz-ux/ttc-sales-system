import { useState, useEffect } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, ShoppingCart, Truck, Package, Eye, Download, Printer, Trash2 } from "lucide-react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { CreatePOModal } from "@/components/modals/CreatePOModal";
import { ViewPOModal } from "@/components/modals/ViewPOModal";
import { useUserRole } from "@/hooks/useUserRole";
import { useUserPermissions } from "@/hooks/useUserPermissions";
import { useUserCategories } from "@/hooks/useUserCategories";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { generatePOPDF, printPO } from "@/utils/pdfExport";

const PurchaseOrders = () => {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [selectedPO, setSelectedPO] = useState<any>(null);
  const [purchaseOrders, setPurchaseOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [poToDelete, setPoToDelete] = useState<any>(null);
  const { isAdmin } = useUserRole();
  const { canCreate, canView, canDelete } = useUserPermissions();
  const { userCategories, hasRestrictions, loading: categoriesLoading } = useUserCategories();
  const { toast } = useToast();

  const displayName = (fullName?: string) => {
    if (!fullName) return 'N/A';
    if (fullName === 'nezartaiz@gmail.com') return 'Nezar';
    if (fullName.includes('@')) {
      const local = fullName.split('@')[0];
      const words = local.replace(/[._-]+/g, ' ').split(' ').filter(Boolean);
      return words.map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
    }
    return fullName;
  };

  const fetchPurchaseOrders = async () => {
    if (categoriesLoading) return;
    
    setLoading(true);
    const { data, error } = await supabase
      .from('purchase_orders')
      .select('*, suppliers(name), purchase_order_items(*, inventory_items(name, category_id)), profiles!purchase_orders_created_by_fkey(full_name)')
      .order('created_at', { ascending: false });
    
    if (error) {
      toast({ title: 'Error', description: `Failed to load purchase orders: ${error.message}`, variant: 'destructive' });
      setPurchaseOrders([]);
    } else {
      // Filter POs based on user's category access
      let filteredData = data || [];
      if (hasRestrictions && userCategories.length > 0) {
        const categoryIds = userCategories.map(c => c.id);
        // Keep POs that have at least one item in user's categories
        filteredData = filteredData.filter(po => {
          const items = po.purchase_order_items || [];
          return items.some((item: any) => categoryIds.includes(item.inventory_items?.category_id));
        });
      }
      setPurchaseOrders(filteredData);
    }
    setLoading(false);
  };

  useEffect(() => {
    if (!categoriesLoading) {
      fetchPurchaseOrders();
    }
  }, [categoriesLoading, userCategories]);

  const handleView = (po: any) => {
    setSelectedPO(po);
    setIsViewModalOpen(true);
  };

  const handleDownloadPDF = (po: any) => {
    generatePOPDF({
      order_number: po.order_number,
      supplier_name: po.suppliers?.name || 'N/A',
      order_date: po.created_at ? new Date(po.created_at).toISOString().split('T')[0] : 'N/A',
      expected_delivery_date: po.expected_delivery_date || 'N/A',
      total_amount: po.total_amount || 0,
      tax_amount: po.tax_amount || 0,
      grand_total: po.grand_total || 0,
      items: po.purchase_order_items?.map((item: any) => ({
        name: item.inventory_items?.name || 'N/A',
        quantity: item.quantity,
        unit_price: item.unit_price,
        total_price: item.total_price
      })) || [],
      notes: po.notes,
      created_by_name: displayName(po.profiles?.full_name),
      customs_duty_status: po.customs_duty_status || undefined,
      discount_type: po.discount_type,
      discount_value: po.discount_value
    });
  };

  const handlePrint = (po: any) => {
    printPO({
      order_number: po.order_number,
      supplier_name: po.suppliers?.name || 'N/A',
      order_date: po.created_at ? new Date(po.created_at).toISOString().split('T')[0] : 'N/A',
      expected_delivery_date: po.expected_delivery_date || 'N/A',
      total_amount: po.total_amount || 0,
      tax_amount: po.tax_amount || 0,
      grand_total: po.grand_total || 0,
      items: po.purchase_order_items?.map((item: any) => ({
        name: item.inventory_items?.name || 'N/A',
        quantity: item.quantity,
        unit_price: item.unit_price,
        total_price: item.total_price
      })) || [],
      notes: po.notes,
      created_by_name: displayName(po.profiles?.full_name),
      customs_duty_status: po.customs_duty_status || undefined,
      discount_type: po.discount_type,
      discount_value: po.discount_value
    });
  };

  const handleDeleteClick = (po: any) => {
    if (!isAdmin && !canDelete('purchase_orders')) {
      toast({ title: 'Permission denied', description: 'You do not have permission to delete purchase orders.', variant: 'destructive' });
      return;
    }
    setPoToDelete(po);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!poToDelete) return;
    
    try {
      const { error } = await supabase
        .from('purchase_orders')
        .delete()
        .eq('id', poToDelete.id);

      if (error) throw error;

      toast({ title: 'Success', description: 'Purchase order deleted successfully' });
      fetchPurchaseOrders();
    } catch (error: any) {
      toast({ title: 'Error', description: `Failed to delete purchase order: ${error.message}`, variant: 'destructive' });
    } finally {
      setDeleteDialogOpen(false);
      setPoToDelete(null);
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Purchase Orders</h1>
            <p className="text-muted-foreground">Manage procurement and supplier orders</p>
          </div>
          <Button 
            className="bg-accent hover:bg-accent/90"
            onClick={() => {
              if (!isAdmin && !canCreate('purchase_orders')) {
                toast({ title: 'Permission denied', description: 'You do not have permission to create purchase orders.', variant: 'destructive' });
                return;
              }
              setIsCreateModalOpen(true);
            }}
            disabled={!isAdmin && !canCreate('purchase_orders')}
          >
            <Plus className="h-4 w-4 mr-2" />
            Create PO
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="border-accent/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total POs</CardTitle>
              <ShoppingCart className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{purchaseOrders.length}</div>
              <p className="text-xs text-muted-foreground">All purchase orders</p>
            </CardContent>
          </Card>

          <Card className="border-yellow-500/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Draft</CardTitle>
              <ShoppingCart className="h-4 w-4 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{purchaseOrders.filter(po => po.status === 'draft').length}</div>
              <p className="text-xs text-muted-foreground">Awaiting approval</p>
            </CardContent>
          </Card>

          <Card className="border-blue-500/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Sent</CardTitle>
              <Truck className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{purchaseOrders.filter(po => po.status === 'sent').length}</div>
              <p className="text-xs text-muted-foreground">Sent to suppliers</p>
            </CardContent>
          </Card>

          <Card className="border-green-500/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Received</CardTitle>
              <Package className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{purchaseOrders.filter(po => po.status === 'received').length}</div>
              <p className="text-xs text-muted-foreground">Completed orders</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Purchase Order Management</CardTitle>
            <CardDescription>Track orders from creation to delivery</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8 text-muted-foreground">Loading purchase orders...</div>
            ) : purchaseOrders.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <ShoppingCart className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No purchase orders found</p>
                <p className="text-sm">Create your first PO using the button above</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>PO #</TableHead>
                      <TableHead>Supplier</TableHead>
                      <TableHead>Expected Delivery</TableHead>
                      <TableHead>Grand Total</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Created By</TableHead>
                      <TableHead>Created</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {purchaseOrders.map((po) => (
                      <TableRow key={po.id}>
                        <TableCell className="font-medium">{po.order_number}</TableCell>
                        <TableCell>{po.suppliers?.name || 'N/A'}</TableCell>
                        <TableCell>{po.expected_delivery_date || 'N/A'}</TableCell>
                        <TableCell>${po.grand_total?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</TableCell>
                        <TableCell>
                          <span className={`capitalize ${
                            po.status === 'delivered' ? 'text-green-600' : 
                            po.status === 'in_transit' ? 'text-blue-600' : 
                            po.status === 'pending' ? 'text-yellow-600' :
                            'text-muted-foreground'
                          }`}>
                            {po.status.replace('_', ' ')}
                          </span>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">{po.profiles?.full_name || 'N/A'}</TableCell>
                        <TableCell>{new Date(po.created_at).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" onClick={() => handleView(po)}>
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => handleDownloadPDF(po)}>
                              <Download className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => handlePrint(po)}>
                              <Printer className="h-4 w-4" />
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              onClick={() => handleDeleteClick(po)}
                              disabled={!isAdmin && !canDelete('purchase_orders')}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <CreatePOModal
        open={isCreateModalOpen}
        onOpenChange={setIsCreateModalOpen}
        onSuccess={fetchPurchaseOrders}
      />
      <ViewPOModal
        open={isViewModalOpen}
        onOpenChange={setIsViewModalOpen}
        purchaseOrder={selectedPO}
      />

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Purchase Order</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete purchase order {poToDelete?.order_number}? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashboardLayout>
  );
};

export default PurchaseOrders;